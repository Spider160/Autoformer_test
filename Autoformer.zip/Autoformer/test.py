import torch

if __name__=='__main__':
    print(torch.ones(5))
    print(torch.version)